module.exports = {
    DB: 'mongodb://ds257752.mlab.com:57752/hiit'
 };